const express = require("express");
const cors = require("cors");
require("dotenv").config();

const OpenAI = require("openai");

const app = express();

const PORT = process.env.PORT || 3000;

const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(cors());
app.use(express.json());


// Health check
app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        message: "AI Assistant backend is running"
    });
});


// AI chat endpoint
app.post("/api/chat", async (req, res) => {

    try {

        const { message } = req.body;

        if (!message || typeof message !== "string") {
            return res.status(400).json({
                success: false,
                error: "A valid message is required."
            });
        }


        const response = await client.responses.create({

            model: "gpt-5.4",

            instructions:
                "You are a helpful, friendly AI assistant. " +
                "Give clear and concise answers.",

            input: message

        });


        res.json({
            success: true,
            response: response.output_text
        });


    } catch (error) {

        console.error("OpenAI API error:", error);

        res.status(500).json({
            success: false,
            error: "The AI service could not process your request."
        });

    }

});


app.listen(PORT, () => {
    console.log(
        `AI Assistant backend running on http://localhost:${PORT}`
    );
});
